// TF2 2008 Android: English main menu - 2026-11-15.
// Idioma seleccionable desde TF2 2008 Actualizador.
"GameMenu" [$WIN32]
{
  "1"
  {
    "label" "Return to Game"
    "command" "ResumeGame"
    "OnlyInGame" "1"
  }
  "2"
  {
    "label" "Disconnect"
    "command" "Disconnect"
    "OnlyInGame" "1"
  }
  "3"
  {
    "label" "Find Servers"
    "command" "OpenServerBrowser"
  }
  "4"
  {
    "label" "Connect by IP (Console)"
    "command" "engine toggleconsole"
  }
  "5"
  {
    "label" "Reconnect to Last Server"
    "command" "engine retry"
  }
  "6"
  {
    "label" "Create LAN Game"
    "command" "OpenCreateMultiplayerGameDialog"
  }
  "7"
  {
    "label" "Player List"
    "command" "OpenPlayerListDialog"
    "OnlyInGame" "1"
  }
  "8"
  {
    "label" "Options"
    "command" "OpenOptionsDialog"
  }
  "9"
  {
    "label" "Quit Game"
    "command" "Quit"
  }
}
