// TF2 2008 Android: menu principal en espanol - build base 2026-11-15.
// Idioma seleccionable desde TF2 2008 Actualizador.
"GameMenu" [$WIN32]
{
  "1"
  {
    "label" "Volver a la partida"
    "command" "ResumeGame"
    "OnlyInGame" "1"
  }
  "2"
  {
    "label" "Salir de la partida"
    "command" "Disconnect"
    "OnlyInGame" "1"
  }
  "3"
  {
    "label" "Buscar servidores"
    "command" "OpenServerBrowser"
  }
  "4"
  {
    "label" "Conectar por IP (consola)"
    "command" "engine toggleconsole"
  }
  "5"
  {
    "label" "Reconectar ultima partida"
    "command" "engine retry"
  }
  "6"
  {
    "label" "Crear partida LAN"
    "command" "OpenCreateMultiplayerGameDialog"
  }
  "7"
  {
    "label" "Lista de jugadores"
    "command" "OpenPlayerListDialog"
    "OnlyInGame" "1"
  }
  "8"
  {
    "label" "Opciones"
    "command" "OpenOptionsDialog"
  }
  "9"
  {
    "label" "Salir del juego"
    "command" "Quit"
  }
}
